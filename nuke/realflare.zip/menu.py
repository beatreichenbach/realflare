nuke.menu('Nodes').addCommand('Realflare/Realflare', 'nuke.createNode("realflare")')
